# تعليمات النشر السريع على Render

## الخطوات المطلوبة:

### 1. رفع المشروع إلى GitHub

```bash
# إنشاء مستودع جديد على GitHub أولاً، ثم:
git init
git add .
git commit -m "Initial commit: Telegram Bot for Pixabay"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git push -u origin main
```

### 2. النشر على Render

1. **اذهب إلى [Render Dashboard](https://dashboard.render.com/)**
2. **اضغط على "New +" ثم "Web Service"**
3. **اربط حساب GitHub واختر المستودع**
4. **املأ البيانات التالية:**
   - **Name:** `telegram-pixabay-bot`
   - **Environment:** `Docker`
   - **Plan:** `Free`
   - **Auto-Deploy:** `Yes`

5. **أضف متغيرات البيئة التالية:**
   ```
   BOT_TOKEN = 8071576925:AAGgx_Jkuu-mRpjdMKiOQCDkkVQskXQYhQo
   PIXABAY_API_KEY = 51444506-bffefcaf12816bd85a20222d1
   ADMIN_ID = 7251748706
   ```

6. **اضغط "Create Web Service"**

### 3. التحقق من النشر

- انتظر حتى يكتمل النشر (قد يستغرق 5-10 دقائق)
- تحقق من السجلات (Logs) للتأكد من عدم وجود أخطاء
- اختبر البوت عبر التليجرام

## ملاحظات مهمة:

- ✅ تأكد من أن البوت مفعل مع @BotFather
- ✅ تأكد من صحة توكن Pixabay API
- ✅ تأكد من أن القنوات المحددة موجودة وصحيحة
- ✅ البوت سيعمل 24/7 على Render مجاناً

## في حالة وجود مشاكل:

1. **تحقق من السجلات في Render Dashboard**
2. **تأكد من صحة متغيرات البيئة**
3. **تأكد من أن Dockerfile موجود في جذر المشروع**

## اختبار البوت:

1. ابحث عن البوت في التليجرام باستخدام اسم المستخدم
2. أرسل `/start`
3. اتبع التعليمات للاشتراك في القنوات
4. جرب البحث عن "cat" أو "design"

