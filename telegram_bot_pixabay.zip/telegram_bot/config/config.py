import os
from dotenv import load_dotenv

load_dotenv()

# إعدادات البوت
BOT_TOKEN = "8071576925:AAGgx_Jkuu-mRpjdMKiOQCDkkVQskXQYhQo"
ADMIN_ID = 7251748706

# إعدادات Pixabay API
PIXABAY_API_KEY = "51444506-bffefcaf12816bd85a20222d1"
PIXABAY_BASE_URL = "https://pixabay.com/api/"

# القنوات الإجبارية
REQUIRED_CHANNELS = ["@crazys7", "@AWU87"]

# أنواع البحث المتاحة
SEARCH_TYPES = {
    "photos": "صور 📷",
    "illustration": "رسوم توضيحية 🎨", 
    "vector": "فيكتور 📐",
    "video": "فيديو 🎬"
}

# رسائل البوت
MESSAGES = {
    "welcome": "مرحباً بك في بوت البحث عن ملحقات التصميم! 🎨\n\nيرجى الاشتراك في القنوات التالية أولاً:",
    "not_subscribed": "يجب عليك الاشتراك في جميع القنوات المطلوبة للمتابعة! 📢",
    "subscribed": "تم التحقق بنجاح! يمكنك الآن استخدام البوت 🎉",
    "search_prompt": "أرسل كلمة البحث التي تريدها:",
    "no_results": "لم يتم العثور على نتائج لهذا البحث 😔",
    "selected": "تم اختيار هذا العنصر! ✅\n\nللبحث مرة أخرى، أرسل /start"
}

