import logging
import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
from config.config import BOT_TOKEN, ADMIN_ID, MESSAGES
from utils import (
    check_user_subscription, 
    create_subscription_keyboard, 
    create_main_menu_keyboard,
    create_search_types_keyboard,
    create_navigation_keyboard,
    search_pixabay,
    format_result_message
)

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# متغيرات لحفظ حالة المستخدمين
user_states = {}
search_results = {}
user_search_types = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج أمر /start"""
    user_id = update.effective_user.id
    
    # إعادة تعيين حالة المستخدم
    user_states[user_id] = "checking_subscription"
    
    # التحقق من الاشتراك
    is_subscribed = await check_user_subscription(context.bot, user_id)
    
    if is_subscribed:
        # المستخدم مشترك، عرض القائمة الرئيسية
        user_states[user_id] = "main_menu"
        await update.message.reply_text(
            MESSAGES["subscribed"],
            reply_markup=create_main_menu_keyboard()
        )
    else:
        # المستخدم غير مشترك، عرض القنوات
        await update.message.reply_text(
            MESSAGES["welcome"],
            reply_markup=create_subscription_keyboard()
        )

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج الأزرار التفاعلية"""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    data = query.data
    
    if data == "check_subscription":
        # التحقق من الاشتراك
        is_subscribed = await check_user_subscription(context.bot, user_id)
        
        if is_subscribed:
            user_states[user_id] = "main_menu"
            await query.edit_message_text(
                MESSAGES["subscribed"],
                reply_markup=create_main_menu_keyboard()
            )
        else:
            await query.edit_message_text(
                MESSAGES["not_subscribed"],
                reply_markup=create_subscription_keyboard()
            )
    
    elif data == "main_menu":
        # العودة للقائمة الرئيسية
        user_states[user_id] = "main_menu"
        await query.edit_message_text(
            "القائمة الرئيسية:",
            reply_markup=create_main_menu_keyboard()
        )
    
    elif data == "start_search":
        # بدء البحث
        if user_states.get(user_id) == "main_menu":
            user_states[user_id] = "waiting_search_query"
            await query.edit_message_text(MESSAGES["search_prompt"])
    
    elif data == "search_types":
        # عرض أنواع البحث
        current_type = user_search_types.get(user_id, "photos")
        await query.edit_message_text(
            "اختر نوع البحث:",
            reply_markup=create_search_types_keyboard(current_type)
        )
    
    elif data.startswith("set_type_"):
        # تعيين نوع البحث
        search_type = data.replace("set_type_", "")
        user_search_types[user_id] = search_type
        
        await query.edit_message_text(
            f"تم تعيين نوع البحث إلى: {search_type} 🧸",
            reply_markup=create_search_types_keyboard(search_type)
        )
    
    elif data.startswith("next_") or data.startswith("prev_"):
        # التنقل بين النتائج
        if user_id in search_results:
            if data.startswith("next_"):
                current_index = int(data.replace("next_", "")) + 1
            else:
                current_index = int(data.replace("prev_", "")) - 1
            
            results = search_results[user_id]["results"]
            search_type = search_results[user_id]["type"]
            
            if 0 <= current_index < len(results):
                result = results[current_index]
                
                # تحديث الرسالة مع النتيجة الجديدة
                message = format_result_message(result, search_type, current_index, len(results))
                
                # إرسال الصورة أو الفيديو
                if search_type == "video":
                    video_url = result.get("videos", {}).get("medium", {}).get("url")
                    if video_url:
                        await query.edit_message_text(message)
                        await context.bot.send_video(
                            chat_id=query.message.chat_id,
                            video=video_url,
                            reply_markup=create_navigation_keyboard(current_index, len(results))
                        )
                else:
                    image_url = result.get("webformatURL")
                    if image_url:
                        await query.edit_message_text(message)
                        await context.bot.send_photo(
                            chat_id=query.message.chat_id,
                            photo=image_url,
                            reply_markup=create_navigation_keyboard(current_index, len(results))
                        )
    
    elif data.startswith("select_"):
        # اختيار النتيجة
        await query.edit_message_text(MESSAGES["selected"])
        # حذف حالة البحث
        if user_id in search_results:
            del search_results[user_id]
        user_states[user_id] = "main_menu"

async def handle_search_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج استعلام البحث"""
    user_id = update.effective_user.id
    
    if user_states.get(user_id) == "waiting_search_query":
        query_text = update.message.text
        search_type = user_search_types.get(user_id, "photos")
        
        # إرسال رسالة انتظار
        waiting_message = await update.message.reply_text("جاري البحث... ⏳")
        
        # البحث في Pixabay
        results = await search_pixabay(query_text, search_type)
        
        if results:
            # حفظ النتائج
            search_results[user_id] = {
                "results": results,
                "type": search_type,
                "query": query_text
            }
            
            # عرض النتيجة الأولى
            result = results[0]
            message = format_result_message(result, search_type, 0, len(results))
            
            # حذف رسالة الانتظار
            await waiting_message.delete()
            
            # إرسال النتيجة
            if search_type == "video":
                video_url = result.get("videos", {}).get("medium", {}).get("url")
                if video_url:
                    await update.message.reply_text(message)
                    await update.message.reply_video(
                        video=video_url,
                        reply_markup=create_navigation_keyboard(0, len(results))
                    )
            else:
                image_url = result.get("webformatURL")
                if image_url:
                    await update.message.reply_text(message)
                    await update.message.reply_photo(
                        photo=image_url,
                        reply_markup=create_navigation_keyboard(0, len(results))
                    )
        else:
            # لا توجد نتائج
            await waiting_message.edit_text(MESSAGES["no_results"])
            user_states[user_id] = "main_menu"

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج الأخطاء"""
    logger.error(f"Exception while handling an update: {context.error}")

def main() -> None:
    """الدالة الرئيسية لتشغيل البوت"""
    # إنشاء التطبيق
    application = Application.builder().token(BOT_TOKEN).build()
    
    # إضافة المعالجات
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_search_query))
    
    # إضافة معالج الأخطاء
    application.add_error_handler(error_handler)
    
    # تشغيل البوت
    print("تم تشغيل البوت...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()

