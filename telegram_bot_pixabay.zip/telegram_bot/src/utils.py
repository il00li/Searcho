import requests
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from config.config import REQUIRED_CHANNELS, PIXABAY_API_KEY, PIXABAY_BASE_URL, SEARCH_TYPES

async def check_user_subscription(bot, user_id):
    """التحقق من اشتراك المستخدم في القنوات المطلوبة"""
    for channel in REQUIRED_CHANNELS:
        try:
            member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
            if member.status in ['left', 'kicked']:
                return False
        except Exception as e:
            print(f"خطأ في التحقق من القناة {channel}: {e}")
            return False
    return True

def create_subscription_keyboard():
    """إنشاء لوحة مفاتيح للقنوات الإجبارية"""
    keyboard = []
    
    # إضافة أزرار القنوات
    for channel in REQUIRED_CHANNELS:
        keyboard.append([InlineKeyboardButton(f"اشترك في {channel}", url=f"https://t.me/{channel[1:]}")])
    
    # إضافة زر التحقق
    keyboard.append([InlineKeyboardButton("تحقق | Check ✅", callback_data="check_subscription")])
    
    return InlineKeyboardMarkup(keyboard)

def create_main_menu_keyboard():
    """إنشاء القائمة الرئيسية بعد التحقق"""
    keyboard = [
        [InlineKeyboardButton("بدء البحث 👁", callback_data="start_search")],
        [InlineKeyboardButton("أنواع البحث 🧸", callback_data="search_types")]
    ]
    return InlineKeyboardMarkup(keyboard)

def create_search_types_keyboard(current_type="photos"):
    """إنشاء لوحة مفاتيح لأنواع البحث"""
    keyboard = []
    
    for search_type, display_name in SEARCH_TYPES.items():
        # إضافة علامة 🧸 للنوع المحدد حالياً
        if search_type == current_type:
            display_name += " 🧸"
        
        keyboard.append([InlineKeyboardButton(display_name, callback_data=f"set_type_{search_type}")])
    
    # زر العودة للقائمة الرئيسية
    keyboard.append([InlineKeyboardButton("العودة للقائمة الرئيسية 🔙", callback_data="main_menu")])
    
    return InlineKeyboardMarkup(keyboard)

def create_navigation_keyboard(current_index, total_results):
    """إنشاء لوحة مفاتيح للتنقل بين النتائج"""
    keyboard = []
    
    # أزرار التنقل
    nav_buttons = []
    if current_index > 0:
        nav_buttons.append(InlineKeyboardButton("⬅️ السابق", callback_data=f"prev_{current_index}"))
    if current_index < total_results - 1:
        nav_buttons.append(InlineKeyboardButton("التالي ➡️", callback_data=f"next_{current_index}"))
    
    if nav_buttons:
        keyboard.append(nav_buttons)
    
    # زر الاختيار
    keyboard.append([InlineKeyboardButton("اختيار 🔒", callback_data=f"select_{current_index}")])
    
    return InlineKeyboardMarkup(keyboard)

async def search_pixabay(query, search_type="photos", per_page=20):
    """البحث في Pixabay API"""
    try:
        # تحديد نوع البحث
        if search_type == "video":
            url = "https://pixabay.com/api/videos/"
        else:
            url = PIXABAY_BASE_URL
        
        params = {
            "key": PIXABAY_API_KEY,
            "q": query,
            "image_type": "all",
            "orientation": "all",
            "category": "all",
            "safesearch": "true",
            "per_page": per_page,
            "lang": "ar"
        }
        
        # إضافة نوع البحث للصور
        if search_type != "video":
            params["category"] = search_type if search_type in ["illustration", "vector"] else "all"
        
        response = requests.get(url, params=params)
        response.raise_for_status()
        
        data = response.json()
        return data.get("hits", [])
        
    except Exception as e:
        print(f"خطأ في البحث: {e}")
        return []

def format_result_message(result, search_type, current_index, total_results):
    """تنسيق رسالة النتيجة"""
    if search_type == "video":
        message = f"🎬 **فيديو {current_index + 1} من {total_results}**\n\n"
        message += f"📝 **العنوان:** {result.get('tags', 'غير متوفر')}\n"
        message += f"⏱️ **المدة:** {result.get('duration', 'غير متوفر')} ثانية\n"
        message += f"👁️ **المشاهدات:** {result.get('views', 0):,}\n"
        message += f"💾 **الحجم:** {result.get('size', 'غير متوفر')}\n"
        message += f"🔗 **الرابط:** {result.get('pageURL', '')}"
    else:
        message = f"🖼️ **صورة {current_index + 1} من {total_results}**\n\n"
        message += f"📝 **الوصف:** {result.get('tags', 'غير متوفر')}\n"
        message += f"📏 **الأبعاد:** {result.get('imageWidth', 0)} × {result.get('imageHeight', 0)}\n"
        message += f"👁️ **المشاهدات:** {result.get('views', 0):,}\n"
        message += f"💾 **التحميلات:** {result.get('downloads', 0):,}\n"
        message += f"🔗 **الرابط:** {result.get('pageURL', '')}"
    
    return message

